(function() {
  $(function() {
    $('.answer-list input').change(function() {
      if ($(this).data('correct') !== false) {
        $(this).closest('.alert').addClass('alert-success');
        $(this).closest('.alert').find('.description').html($(this).data('correct'));
      } else {
        $(this).closest('.alert').addClass('alert-danger');
      }
      return $(this).closest('.answer-list').find('input').each(function() {
        return $(this).addClass('disabled').attr('disabled', true);
      });
    });
    return $('#get-results').click(function() {
      var correct_answers;
      $('.answer-list input').each(function() {
        $(this).addClass('disabled').attr('disabled', true);
        return $(this).closest('.alert').siblings().andSelf().each(function() {
          if ($(this).find('input').data('correct') !== false) {
            return $(this).addClass('text-success');
          } else {
            return $(this).addClass('text-danger');
          }
        });
      });
      correct_answers = 0;
      $('.answer-list input:checked').each(function() {
        if ($(this).data('correct') !== false) {
          return correct_answers++;
        }
      });
      return $('.result').each(function() {
        if (correct_answers <= $(this).data('upper') && correct_answers >= $(this).data('lower')) {
          $(this).show();
        }
        $('.num-correct').text(correct_answers);
        return $('.percent-correct').text((correct_answers / $(this).data('question-count') * 100).toFixed(2));
      });
    });
  });

}).call(this);
